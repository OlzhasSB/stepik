//
//  Cast.swift
//  Kinopoisk
//
//  Created by Olzhas Seiilkhanov on 17.05.2022.
//

import UIKit

struct Cast {
    var name: String?
    var status: String?
    var image: UIImage?
    var birthday: String?
    var biography: String?
}
