//
//  Genre.swift
//  Kinopoisk
//
//  Created by Olzhas Seiilkhanov on 20.05.2022.
//

import UIKit

struct Genre {
    var text: String?
}
