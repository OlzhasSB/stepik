//
//  CreditsEntity.swift
//  Kinopoisk
//
//  Created by Olzhas Seiilkhanov on 30.05.2022.
//

import Foundation
