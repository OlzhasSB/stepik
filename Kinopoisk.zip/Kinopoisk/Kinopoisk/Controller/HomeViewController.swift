//
//  TestViewController.swift
//  Kinopoisk
//
//  Created by Olzhas Seiilkhanov on 24.05.2022.
//

import UIKit

class HomeViewController: UIViewController {
    private var networkManager = NetworkManager.shared
    private var genres: [Genre] = []
    
    private var todayMovies: [Movie] = [] {
        didSet {
            todayCollectionView.reloadData()
        }
    }
    
    
    @IBOutlet private var sectionTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Movies"
        setUp()
        loadGenres()
    }
    
    private func setUp() {
        sectionTableView.dataSource = self
        sectionTableView.delegate = self
    }

}

extension HomeViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        return data.sections.count
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "sectionCell") as! TableSectionCell
//        cell.sectionLabel.text = data.sections[indexPath.row]
//        cell.films = data.movies
        cell.delegate = self
        return cell
    }
}

extension HomeViewController: UIdelegate {
    func goToNext() {
        if let vc = storyboard?.instantiateViewController(withIdentifier: "MovieNewsViewController") as? MovieNewsViewController {
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
}

extension HomeViewController {
    private func loadGenres() {
        networkManager.loadGenres { [weak self] genres in
            self?.genres = genres
            self?.loadMovies()
        }
    }
    
    private func loadMovies() {
        networkManager.loadTodayMovies { [weak self] genres in
            self?.todayMovies = movies
        }
        networkManager.loadSoonMovies { [weak self] genres in
            self?.soonMovies = movies
        }
        networkManager.loadTrendingMovies { [weak self] genres in
            self?.trendingMovies = movies
        }
    }
}
