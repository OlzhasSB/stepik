//
//  CastCell.swift
//  Kinopoisk
//
//  Created by Olzhas Seiilkhanov on 17.05.2022.
//

import UIKit

class CastCell: UICollectionViewCell {
    @IBOutlet var castImageView: UIImageView!
    @IBOutlet var castName: UILabel!
    @IBOutlet var castStatus: UILabel!
    
//    func setUp(with cast: Cast) {
//        castImageView.image = cast.image
//        castName.text = cast.name
//        castStatus.text = cast.status
//    }
}
